# Wokwi project

This is a Wokwi project. Please edit this README file and add a description of your project.

## Usage

1. Add parts by clicking the blue "+" button in the diagram editor
2. Connect parts by dragging wires between them
3. Click the green play button to start the simulation
